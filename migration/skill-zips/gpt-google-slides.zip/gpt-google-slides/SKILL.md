---
name: gpt-google-slides
description: "기존 Google Slides(구글 슬라이드) 템플릿·덱을 분석하거나 복사본으로 수정하는 요청에 사용. 레이아웃·글꼴·미디어 비율을 보존하고 완성본 전체를 렌더링해 확인. 참조 없는 새 발표자료에는 사용하지 않음."
---

# 기존 Google Slides 템플릿 분석·수정·발표자료 보존

이 문서는 GPT의 스킬과 노출 도구를 바탕으로 Claude용으로 새로 작성한 이식 지침이다. 원문 보관본이나 과거 사용자 메모리가 아니다. 여기 언급된 도구는 현재 Claude의 연결 목록과 스키마에서 실제 지원 여부를 확인한 뒤 사용한다. 없는 기능의 실행·연결·게시 성공을 주장하지 않는다.

## 연결 전제

전체 덱 구조 읽기·네이티브 편집·PDF 내보내기/렌더링 기능 필요.

## Claude 도구 대응

- Claude의 Google Drive 커넥터에서 확인된 도구: `search_files`, `list_recent_files`, `get_file_metadata`, `read_file_content`(댓글 포함 읽기 지원), `download_file_content`, `create_file`, `update_file`, `copy_file`, `share_file`, `get_file_permissions`, `trash_file`. 도구 접두어는 환경마다 다르므로 실제 목록에서 이름을 확인한다.
- 스키마로 확인한 제약: `update_file`은 제목·설명·부모 폴더(이동)만 바꾸며 **파일 내용은 덮어쓰지 못한다**. `create_file`은 업로드한 docx·xlsx·pptx·텍스트를 기본적으로 Google 네이티브 형식으로 변환한다(`disableConversionToGoogleType: true`면 원형 유지). `download_file_content`는 네이티브 파일을 `exportMimeType`(docx·xlsx·pptx·pdf 등)으로 내보내며 지정하지 않으면 일반 텍스트/CSV다. `revisionId`로 이전 버전을 받을 수 있다. `read_file_content`는 큰 파일에서 일부만 반환할 수 있다.
- 따라서 기존 네이티브 문서의 내용 수정 결과는 **새 파일**(원본 옆 복사본 등)로 만들어진다. 원본 대체(이름 교환·원본 휴지통 이동)는 사용자가 요청할 때만 한다.
- 템플릿 복사는 `copy_file`. 현재 커넥터에는 Slides 네이티브 편집 API가 없으므로 `download_file_content`(`exportMimeType: application/vnd.openxmlformats-officedocument.presentationml.presentation`)로 받아 `pptx` 스킬로 편집하고, 결과를 `create_file`로 새 프레젠테이션으로 올린다.
- 원본 전체 확인은 `exportMimeType: application/pdf`로 내보낸 뒤 페이지 이미지로 렌더링(예: `pdftoppm`)해 모든 슬라이드를 본다. 수정본도 같은 방식으로 다시 렌더링한다.
- 참조 없는 새 발표자료는 Claude의 슬라이드 Artifact 유형 또는 pptx 스킬을 사용한다.

## 작업 지침

1. 기존 템플릿이나 참조 덱을 먼저 전체 구조로 읽고 PDF로 렌더링해 모든 슬라이드를 확인한다.

2. 마스터·레이아웃·플레이스홀더·글꼴·색·도형 배치·보호 영역을 기록한다.

3. 템플릿을 따르는 새 자료는 원본을 복사하고 복사본만 편집한다.

4. 각 출력 슬라이드의 역할에 맞는 원본 예시 또는 레이아웃을 선택한다.

5. 원래의 편집 가능한 도형·표·차트·문단·혼합 텍스트 스타일을 유지하고 각 이미지·영상·예시 콘텐츠를 유지/교체/삭제 중 하나로 명확히 처리한다.

6. 의미 있는 화면·도표는 잘리지 않게 맞추고 모든 미디어의 종횡비를 보존한다.

7. 본문을 무리하게 축소하기보다 적합한 예시나 내용 분량을 선택한다.

8. 빈 글머리표, 오래된 이름·날짜·연락처, 미치환 플레이스홀더를 점검한다.

9. 최종 순서와 슬라이드 ID를 읽고 완성본 전체를 렌더링해 확인한다.

10. ChatGPT Presentations와 전용 렌더러는 Claude에 자동 설치되지 않는다.

11. 참조 없는 새 발표자료는 사용 가능한 Claude 문서 작성 기능으로 별도 처리한다.

## 출처

google-drive:google-slides. 기존 도구명과 GPT 전용 문법은 그대로 실행하지 않고 현재 도구에 대응시킨다.
